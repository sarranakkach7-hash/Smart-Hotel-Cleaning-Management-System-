-- ============================================================
-- Smart Hotel Cleaning Management System — Database Setup
-- Run this once in phpMyAdmin or MySQL CLI:
--   mysql -u root -p < hotel_cleaning.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS hotel_cleaning CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hotel_cleaning;

-- ── USERS (guests, staff, admins) ──────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,        -- store hashed passwords
    role        ENUM('client','staff','admin') NOT NULL DEFAULT 'client',
    room        VARCHAR(20)  DEFAULT NULL,    -- room number (clients)
    shift       VARCHAR(20)  DEFAULT NULL,    -- Morning/Afternoon/Night (staff)
    staff_role  VARCHAR(50)  DEFAULT NULL,    -- Cleaner/Supervisor (staff)
    status      ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at  DATETIME DEFAULT NOW()
);

-- ── ROOMS ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rooms (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(20) NOT NULL UNIQUE,
    floor       INT         DEFAULT 1,
    type        VARCHAR(50) DEFAULT 'Standard',
    status      ENUM('clean','dirty','in_progress') DEFAULT 'clean'
);

-- ── CLEANING REQUESTS ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS cleaning_requests (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    room            VARCHAR(20) NOT NULL,
    request_type    ENUM('clean','donotclean','urgent') NOT NULL DEFAULT 'clean',
    description     TEXT        DEFAULT NULL,
    status          ENUM('pending','in_progress','completed') NOT NULL DEFAULT 'pending',
    assigned_staff  INT         DEFAULT NULL,   -- FK to users.id (staff)
    created_at      DATETIME    DEFAULT NOW(),
    updated_at      DATETIME    DEFAULT NOW() ON UPDATE NOW(),
    FOREIGN KEY (user_id)        REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_staff) REFERENCES users(id) ON DELETE SET NULL
);

-- ── STAFF SCHEDULE ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS staff_schedule (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    staff_id        INT NOT NULL,
    schedule_date   DATE        NOT NULL,
    shift           VARCHAR(20) NOT NULL,
    start_time      VARCHAR(20) DEFAULT NULL,
    end_time        VARCHAR(20) DEFAULT NULL,
    rooms_assigned  VARCHAR(100) DEFAULT NULL,
    FOREIGN KEY (staff_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ── SETTINGS ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS settings (
    `key`   VARCHAR(100) PRIMARY KEY,
    `value` TEXT
);

-- ── CLIENT PREFERENCES ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS client_preferences (
    user_id         INT PRIMARY KEY,
    early_morning   TINYINT DEFAULT 0,
    dnd             TINYINT DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ── SEED DATA ──────────────────────────────────────────────
-- Default admin (password: admin123)
INSERT IGNORE INTO users (name, email, password, role) VALUES
('Administrator', 'admin@hotel.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Sample staff (password: staff123)
INSERT IGNORE INTO users (name, email, password, role, shift, staff_role, status) VALUES
('Ahmed Mohamed', 'ahmed@hotel.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'staff', 'Morning',   'Cleaner',    'active'),
('Fatima Ali',    'fatima@hotel.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'staff', 'Afternoon', 'Supervisor', 'active');

-- Sample guest (password: guest123)
INSERT IGNORE INTO users (name, email, password, role, room) VALUES
('John Guest', 'guest@hotel.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'client', '101');

-- Sample rooms
INSERT IGNORE INTO rooms (room_number, floor, type) VALUES
('101', 1, 'Standard'), ('102', 1, 'Standard'), ('103', 1, 'Standard'),
('201', 2, 'Deluxe'),   ('202', 2, 'Deluxe'),
('301', 3, 'Suite');

-- Default settings
INSERT IGNORE INTO settings (`key`,`value`) VALUES
('hotel_name',   'Dar Tunis Hotel'),
('total_rooms',  '150'),
('opening_time', '06:00'),
('closing_time', '22:00');

-- Sample schedule for staff
INSERT IGNORE INTO staff_schedule (staff_id, schedule_date, shift, start_time, end_time, rooms_assigned)
SELECT u.id, CURDATE(), 'Morning', '06:00 AM', '02:00 PM', '101-110'
FROM users u WHERE u.email = 'ahmed@hotel.com' LIMIT 1;

-- NOTE: The default password hash above is for the string "password"
-- To generate proper hashes, use PHP: password_hash('yourpassword', PASSWORD_DEFAULT)
-- Or use the register.php page which hashes automatically.
