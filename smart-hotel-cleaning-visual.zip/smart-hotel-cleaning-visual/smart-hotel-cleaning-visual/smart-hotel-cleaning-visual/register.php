<?php
session_start();
include 'db.php';

$success = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $room = trim($_POST['room'] ?? '');

    if($name && $email && $password) {

        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $result = $check->get_result();

        if($result->num_rows > 0) {
            $error = "Email already exists";
        } else {

            $stmt = $conn->prepare(
                "INSERT INTO users(name, email, password, role, room)
                 VALUES(?, ?, ?, 'client', ?)"
            );

            $stmt->bind_param("ssss", $name, $email, $password, $room);

            if($stmt->execute()) {
                $success = "Account created successfully";
                header("refresh:2;url=login.php");
            } else {
                $error = "Registration failed";
            }
        }
    } else {
        $error = "Please fill all required fields";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="container">
    <h2>Create Account</h2>

    <?php if($success): ?>
        <p style="color:green;">
            <?php echo $success; ?>
        </p>
    <?php endif; ?>

    <?php if($error): ?>
        <p style="color:red;">
            <?php echo $error; ?>
        </p>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="name" placeholder="Full Name" required>
        <br><br>

        <input type="email" name="email" placeholder="Email" required>
        <br><br>

        <input type="password" name="password" placeholder="Password" required>
        <br><br>

        <input type="text" name="room" placeholder="Room Number">
        <br><br>

        <button type="submit">Register</button>
    </form>
</div>

</body>
</html>