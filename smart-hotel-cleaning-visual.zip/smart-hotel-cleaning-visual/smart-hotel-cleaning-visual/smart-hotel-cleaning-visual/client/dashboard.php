<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'client') {
    header('Location: ../login.php');
    exit();
}
include '../db.php';

$success = '';
$error   = '';

$user_id = (int)($_SESSION['user_id'] ?? 0);
$room    = $_SESSION['room'] ?? '';

// ── SUBMIT CLEANING CHOICE ─────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    if ($_POST['action'] === 'set_cleaning') {
        $choice = $_POST['choice'] === 'clean' ? 'clean' : 'donotclean';
        // Insert a new request for today
        $stmt = $conn->prepare(
            "INSERT INTO cleaning_requests (user_id, room, request_type, status, created_at)
             VALUES (?, ?, ?, 'pending', NOW())"
        );
        $stmt->bind_param("iss", $user_id, $room, $choice);
        $stmt->execute()
            ? $success = "Preference saved: " . ($choice === 'clean' ? 'Room will be cleaned.' : 'Do Not Clean set.')
            : $error   = "Failed to save preference.";
    }

    elseif ($_POST['action'] === 'urgent') {
        $description = trim($_POST['description'] ?? '');
        if ($description) {
            $type = 'urgent';
            $stmt = $conn->prepare(
                "INSERT INTO cleaning_requests (user_id, room, request_type, description, status, created_at)
                 VALUES (?, ?, ?, ?, 'pending', NOW())"
            );
            $stmt->bind_param("isss", $user_id, $room, $type, $description);
            $stmt->execute()
                ? $success = "Urgent cleaning request submitted."
                : $error   = "Failed to submit urgent request.";
        } else {
            $error = "Please describe your urgent cleaning need.";
        }
    }

    elseif ($_POST['action'] === 'save_preferences') {
        $early  = isset($_POST['early_morning']) ? 1 : 0;
        $dnd    = isset($_POST['dnd']) ? 1 : 0;
        $conn->query("CREATE TABLE IF NOT EXISTS client_preferences (
            user_id INT PRIMARY KEY,
            early_morning TINYINT DEFAULT 0,
            dnd TINYINT DEFAULT 0
        )");
        $stmt = $conn->prepare(
            "INSERT INTO client_preferences (user_id, early_morning, dnd)
             VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE early_morning=?, dnd=?"
        );
        $stmt->bind_param("iiiii", $user_id, $early, $dnd, $early, $dnd);
        $stmt->execute()
            ? $success = "Preferences saved."
            : $error   = "Failed to save preferences.";
    }
}

// ── FETCH DATA ─────────────────────────────────────────────────────────────

// Today's status for this room
$today_status = null;
if ($room) {
    $ts = $conn->prepare(
        "SELECT status, request_type FROM cleaning_requests
         WHERE user_id=? AND DATE(created_at)=CURDATE()
         ORDER BY created_at DESC LIMIT 1"
    );
    $ts->bind_param("i", $user_id);
    $ts->execute();
    $today_status = $ts->get_result()->fetch_assoc();
}

// Request history
$history = [];
if ($user_id) {
    $hr = $conn->prepare(
        "SELECT room, request_type, status, description, DATE_FORMAT(created_at,'%Y-%m-%d') AS date
         FROM cleaning_requests WHERE user_id=?
         ORDER BY created_at DESC LIMIT 20"
    );
    $hr->bind_param("i", $user_id);
    $hr->execute();
    $res = $hr->get_result();
    while ($row = $res->fetch_assoc()) $history[] = $row;
}

// Preferences
$conn->query("CREATE TABLE IF NOT EXISTS client_preferences (
    user_id INT PRIMARY KEY, early_morning TINYINT DEFAULT 0, dnd TINYINT DEFAULT 0
)");
$prefs = ['early_morning' => 1, 'dnd' => 0];
$pr = $conn->prepare("SELECT early_morning, dnd FROM client_preferences WHERE user_id=?");
$pr->bind_param("i", $user_id);
$pr->execute();
$prow = $pr->get_result()->fetch_assoc();
if ($prow) $prefs = $prow;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guest Dashboard - Smart Hotel Cleaning</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="logo">🏨 Hotel Cleaning System</div>
            <ul class="nav-links">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="dashboard-grid">
            <aside class="sidebar">
                <h3>Guest Menu</h3>
                <p style="font-size:0.85rem;color:#666;padding:0 10px;">
                    👤 <?php echo htmlspecialchars($_SESSION['name'] ?? $_SESSION['user']); ?>
                    <?php if ($room): ?><br>🛏 Room <?php echo htmlspecialchars($room); ?><?php endif; ?>
                </p>
                <ul class="menu">
                    <li><a href="#cleaning-status" class="active">Cleaning Status</a></li>
                    <li><a href="#history">Request History</a></li>
                    <li><a href="#preferences">Preferences</a></li>
                </ul>
            </aside>

            <main class="main-content">

                <!-- ── CLEANING STATUS ── -->
                <section id="cleaning-status" class="content-section">
                    <h2>Cleaning Management</h2>
                    <div class="card">
                        <h3>Room <?php echo htmlspecialchars($room ?: 'N/A'); ?></h3>

                        <?php if ($today_status): ?>
                            <p>Today's Status:
                                <span class="badge <?php echo $today_status['status'] === 'completed' ? 'badge-completed' : 'badge-pending'; ?>">
                                    <?php echo ucfirst($today_status['status']); ?>
                                </span>
                                — <em><?php echo htmlspecialchars($today_status['request_type']); ?></em>
                            </p>
                        <?php else: ?>
                            <p>Today's Status: <span class="badge badge-pending">Not Set</span></p>
                        <?php endif; ?>

                        <form method="POST">
                            <input type="hidden" name="action" value="set_cleaning">
                            <div class="button-group" style="margin-top:15px;">
                                <button type="submit" name="choice" value="clean" class="btn btn-success">
                                    ✓ Clean the Room
                                </button>
                                <button type="submit" name="choice" value="donotclean" class="btn btn-danger">
                                    ✗ Do Not Clean
                                </button>
                            </div>
                        </form>

                        <div class="urgent-section" style="margin-top:20px;">
                            <h4>Urgent Request</h4>
                            <form method="POST">
                                <input type="hidden" name="action" value="urgent">
                                <textarea name="description"
                                          placeholder="Describe your urgent cleaning need..."
                                          rows="3" style="width:100%;padding:8px;box-sizing:border-box;"></textarea>
                                <button type="submit" class="btn btn-warning" style="margin-top:10px;">
                                    Request Urgent Cleaning
                                </button>
                            </form>
                        </div>
                    </div>
                </section>

                <!-- ── HISTORY ── -->
                <section id="history" class="content-section">
                    <h2>Request History</h2>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Room</th>
                                <th>Request Type</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($history): ?>
                            <?php foreach ($history as $h): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($h['room']); ?></td>
                                <td><?php echo htmlspecialchars(ucfirst($h['request_type'])); ?></td>
                                <td><?php echo htmlspecialchars($h['description'] ?? '—'); ?></td>
                                <td>
                                    <span class="badge <?php echo $h['status'] === 'completed' ? 'badge-completed' : 'badge-pending'; ?>">
                                        <?php echo ucfirst($h['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo $h['date']; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="5" style="text-align:center;">No requests yet.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </section>

                <!-- ── PREFERENCES ── -->
                <section id="preferences" class="content-section">
                    <h2>Cleaning Preferences</h2>
                    <form method="POST" class="preferences-form">
                        <input type="hidden" name="action" value="save_preferences">
                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="early_morning" value="1"
                                       <?php echo $prefs['early_morning'] ? 'checked' : ''; ?>>
                                Early morning cleaning (6–8 AM)
                            </label>
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="dnd" value="1"
                                       <?php echo $prefs['dnd'] ? 'checked' : ''; ?>>
                                Do Not Disturb preference
                            </label>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Preferences</button>
                    </form>
                </section>

            </main>
        </div>
    </div>
</body>
</html>
