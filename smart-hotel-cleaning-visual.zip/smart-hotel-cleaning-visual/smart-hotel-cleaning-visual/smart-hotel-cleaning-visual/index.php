<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Hotel Cleaning Management System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="logo"> Hotel Cleaning System</div>
            <ul class="nav-links">
                <li><a href="index.php">Home</a></li>
                <?php if(isset($_SESSION['user'])): ?>
                    <li><a href="logout.php">Logout (<?php echo $_SESSION['user']; ?>)</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <section class="hero">
        <div class="container">
            <h1>Smart Hotel Cleaning Management System</h1>
            <p>Efficient room cleaning coordination for modern hotels</p>
            <div class="hero-buttons">
                <a href="login.php" class="btn btn-primary">Login</a>
                <a href="register.php" class="btn btn-secondary">Create Account</a>
            </div>
        </div>
    </section>

    <section class="features">
        <div class="container">
            <h2>Why Choose Us?</h2>
            <div class="feature-grid">
                <div class="feature-card">
                    <h3>✅ Real-Time Updates</h3>
                    <p>Instant notifications for cleaning requests and status updates</p>
                </div>
                <div class="feature-card">
                    <h3>📱 Easy to Use</h3>
                    <p>Simple interface accessible from any device</p>
                </div>
                <div class="feature-card">
                    <h3>🔒 Secure</h3>
                    <p>Encrypted access and user authentication</p>
                </div>
                <div class="feature-card">
                    <h3>📊 Reports</h3>
                    <p>Generate cleaning performance reports</p>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <p> 2025 Smart Hotel Cleaning Management System. All rights reserved.</p>
    </footer>
</body>
</html>