<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}
include '../db.php';

$success = '';
$error   = '';

// ── ADD STAFF ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    if ($_POST['action'] === 'add_staff') {
        $name     = trim($_POST['name'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $shift    = trim($_POST['shift'] ?? '');
        $staff_role = trim($_POST['staff_role'] ?? 'Cleaner');

        if ($name && $email && $password && $shift) {
            $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $check->bind_param("s", $email);
            $check->execute();
            if ($check->get_result()->num_rows > 0) {
                $error = "Email already exists.";
            } else {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare(
                    "INSERT INTO users (name, email, password, role, shift, staff_role)
                     VALUES (?, ?, ?, 'staff', ?, ?)"
                );
                $stmt->bind_param("sssss", $name, $email, $hashed, $shift, $staff_role);
                $stmt->execute() ? $success = "Staff member added." : $error = "Failed to add staff.";
            }
        } else {
            $error = "Please fill all required fields.";
        }
    }

    // ── EDIT STAFF ───────────────────────────────────────────────────────
    elseif ($_POST['action'] === 'edit_staff') {
        $id       = (int)($_POST['staff_id'] ?? 0);
        $name     = trim($_POST['name'] ?? '');
        $shift    = trim($_POST['shift'] ?? '');
        $staff_role = trim($_POST['staff_role'] ?? '');
        $status   = trim($_POST['status'] ?? 'active');

        if ($id && $name && $shift) {
            $stmt = $conn->prepare(
                "UPDATE users SET name=?, shift=?, staff_role=?, status=? WHERE id=? AND role='staff'"
            );
            $stmt->bind_param("ssssi", $name, $shift, $staff_role, $status, $id);
            $stmt->execute() ? $success = "Staff updated." : $error = "Update failed.";
        } else {
            $error = "Missing fields for edit.";
        }
    }

    // ── DELETE STAFF ─────────────────────────────────────────────────────
    elseif ($_POST['action'] === 'delete_staff') {
        $id = (int)($_POST['staff_id'] ?? 0);
        if ($id) {
            $stmt = $conn->prepare("DELETE FROM users WHERE id=? AND role='staff'");
            $stmt->bind_param("i", $id);
            $stmt->execute() ? $success = "Staff deleted." : $error = "Delete failed.";
        }
    }

    // ── SAVE SETTINGS ────────────────────────────────────────────────────
    elseif ($_POST['action'] === 'save_settings') {
        $hotel_name   = trim($_POST['hotel_name'] ?? '');
        $total_rooms  = (int)($_POST['total_rooms'] ?? 0);
        $opening_time = trim($_POST['opening_time'] ?? '');
        $closing_time = trim($_POST['closing_time'] ?? '');

        if ($hotel_name && $total_rooms && $opening_time && $closing_time) {
            // Upsert settings
            $conn->query("CREATE TABLE IF NOT EXISTS settings (
                `key` VARCHAR(100) PRIMARY KEY,
                `value` TEXT
            )");
            $pairs = [
                'hotel_name'   => $hotel_name,
                'total_rooms'  => $total_rooms,
                'opening_time' => $opening_time,
                'closing_time' => $closing_time,
            ];
            foreach ($pairs as $k => $v) {
                $stmt = $conn->prepare("INSERT INTO settings (`key`,`value`) VALUES(?,?) ON DUPLICATE KEY UPDATE `value`=?");
                $stmt->bind_param("sss", $k, $v, $v);
                $stmt->execute();
            }
            $success = "Settings saved.";
        } else {
            $error = "Please fill all settings fields.";
        }
    }
}

// ── FETCH DATA ─────────────────────────────────────────────────────────────

// Stats
$total_rooms_res  = $conn->query("SELECT COUNT(*) AS c FROM rooms");
$total_rooms_count = $total_rooms_res ? (int)$total_rooms_res->fetch_assoc()['c'] : 0;

$total_staff_res  = $conn->query("SELECT COUNT(*) AS c FROM users WHERE role='staff'");
$total_staff_count = $total_staff_res ? (int)$total_staff_res->fetch_assoc()['c'] : 0;

$pending_res      = $conn->query("SELECT COUNT(*) AS c FROM cleaning_requests WHERE status='pending'");
$pending_count    = $pending_res ? (int)$pending_res->fetch_assoc()['c'] : 0;

$completed_res    = $conn->query("SELECT COUNT(*) AS c FROM cleaning_requests WHERE status='completed'");
$completed_count  = $completed_res ? (int)$completed_res->fetch_assoc()['c'] : 0;
$completion_rate  = ($completed_count + $pending_count) > 0
    ? round($completed_count / ($completed_count + $pending_count) * 100) . '%'
    : 'N/A';

// Staff list
$staff_result = $conn->query(
    "SELECT id, name, email, COALESCE(staff_role,'Cleaner') AS staff_role,
            COALESCE(shift,'Morning') AS shift,
            COALESCE(status,'active') AS status
     FROM users WHERE role='staff' ORDER BY name"
);

// Settings
$conn->query("CREATE TABLE IF NOT EXISTS settings (`key` VARCHAR(100) PRIMARY KEY, `value` TEXT)");
$settings = [];
$sr = $conn->query("SELECT `key`,`value` FROM settings");
if ($sr) while ($row = $sr->fetch_assoc()) $settings[$row['key']] = $row['value'];

// Edit target (when edit button clicked)
$edit_staff = null;
if (isset($_GET['edit_staff'])) {
    $eid = (int)$_GET['edit_staff'];
    $es  = $conn->prepare("SELECT * FROM users WHERE id=? AND role='staff'");
    $es->bind_param("i", $eid);
    $es->execute();
    $edit_staff = $es->get_result()->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Smart Hotel Cleaning</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="logo">🏨 Hotel Cleaning System</div>
            <ul class="nav-links">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <h1>Administrator Dashboard</h1>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3><?php echo $total_rooms_count; ?></h3>
                <p>Total Rooms</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $total_staff_count; ?></h3>
                <p>Cleaning Staff</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $completion_rate; ?></h3>
                <p>Completion Rate</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $pending_count; ?></h3>
                <p>Pending Requests</p>
            </div>
        </div>

        <div class="admin-sections">

            <!-- ── STAFF MANAGEMENT ── -->
            <section class="admin-section">
                <h2>Staff Management</h2>

                <?php if ($edit_staff): ?>
                <!-- Edit Staff Form -->
                <form method="POST" class="settings-form" style="margin-bottom:20px;">
                    <input type="hidden" name="action" value="edit_staff">
                    <input type="hidden" name="staff_id" value="<?php echo $edit_staff['id']; ?>">
                    <h3>Edit Staff: <?php echo htmlspecialchars($edit_staff['email']); ?></h3>
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="name" value="<?php echo htmlspecialchars($edit_staff['name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Role</label>
                        <select name="staff_role">
                            <option value="Cleaner" <?php echo ($edit_staff['staff_role'] ?? '') === 'Cleaner' ? 'selected' : ''; ?>>Cleaner</option>
                            <option value="Supervisor" <?php echo ($edit_staff['staff_role'] ?? '') === 'Supervisor' ? 'selected' : ''; ?>>Supervisor</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Shift</label>
                        <select name="shift">
                            <option value="Morning" <?php echo ($edit_staff['shift'] ?? '') === 'Morning' ? 'selected' : ''; ?>>Morning</option>
                            <option value="Afternoon" <?php echo ($edit_staff['shift'] ?? '') === 'Afternoon' ? 'selected' : ''; ?>>Afternoon</option>
                            <option value="Night" <?php echo ($edit_staff['shift'] ?? '') === 'Night' ? 'selected' : ''; ?>>Night</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="active" <?php echo ($edit_staff['status'] ?? '') === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo ($edit_staff['status'] ?? '') === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                    <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
                </form>
                <?php endif; ?>

                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Shift</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($staff_result && $staff_result->num_rows > 0): ?>
                        <?php while ($staff = $staff_result->fetch_assoc()): ?>
                        <tr>
                            <td>S<?php echo str_pad($staff['id'], 3, '0', STR_PAD_LEFT); ?></td>
                            <td><?php echo htmlspecialchars($staff['name']); ?></td>
                            <td><?php echo htmlspecialchars($staff['email']); ?></td>
                            <td><?php echo htmlspecialchars($staff['staff_role']); ?></td>
                            <td><?php echo htmlspecialchars($staff['shift']); ?></td>
                            <td>
                                <span class="badge <?php echo $staff['status'] === 'active' ? 'badge-active' : 'badge-pending'; ?>">
                                    <?php echo ucfirst($staff['status']); ?>
                                </span>
                            </td>
                            <td>
                                <a href="dashboard.php?edit_staff=<?php echo $staff['id']; ?>"
                                   class="btn btn-sm btn-info">Edit</a>
                                <form method="POST" style="display:inline;"
                                      onsubmit="return confirm('Delete this staff member?')">
                                    <input type="hidden" name="action" value="delete_staff">
                                    <input type="hidden" name="staff_id" value="<?php echo $staff['id']; ?>">
                                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" style="text-align:center;">No staff members found.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>

                <!-- Add New Staff Form -->
                <details style="margin-top:15px;">
                    <summary class="btn btn-primary" style="cursor:pointer;display:inline-block;">+ Add New Staff</summary>
                    <form method="POST" class="settings-form" style="margin-top:15px;">
                        <input type="hidden" name="action" value="add_staff">
                        <div class="form-group">
                            <label>Full Name <span style="color:red">*</span></label>
                            <input type="text" name="name" required>
                        </div>
                        <div class="form-group">
                            <label>Email <span style="color:red">*</span></label>
                            <input type="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label>Password <span style="color:red">*</span></label>
                            <input type="password" name="password" required>
                        </div>
                        <div class="form-group">
                            <label>Role</label>
                            <select name="staff_role">
                                <option value="Cleaner">Cleaner</option>
                                <option value="Supervisor">Supervisor</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Shift <span style="color:red">*</span></label>
                            <select name="shift">
                                <option value="Morning">Morning</option>
                                <option value="Afternoon">Afternoon</option>
                                <option value="Night">Night</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Add Staff Member</button>
                    </form>
                </details>
            </section>

            <!-- ── SYSTEM SETTINGS ── -->
            <section class="admin-section">
                <h2>System Settings</h2>
                <form method="POST" class="settings-form">
                    <input type="hidden" name="action" value="save_settings">
                    <div class="form-group">
                        <label>Hotel Name</label>
                        <input type="text" name="hotel_name"
                               value="<?php echo htmlspecialchars($settings['hotel_name'] ?? 'Dar Tunis Hotel'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Total Rooms</label>
                        <input type="number" name="total_rooms"
                               value="<?php echo htmlspecialchars($settings['total_rooms'] ?? '150'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Opening Time</label>
                        <input type="time" name="opening_time"
                               value="<?php echo htmlspecialchars($settings['opening_time'] ?? '06:00'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Closing Time</label>
                        <input type="time" name="closing_time"
                               value="<?php echo htmlspecialchars($settings['closing_time'] ?? '22:00'); ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Settings</button>
                </form>
            </section>

        </div><!-- /admin-sections -->
    </div><!-- /container -->
</body>
</html>
