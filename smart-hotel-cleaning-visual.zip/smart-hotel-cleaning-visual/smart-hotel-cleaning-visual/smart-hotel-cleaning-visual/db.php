<?php
$host     = "localhost";
$user     = "root";
$password = "";
$database = "hotel_cleaning_v2";

$conn = new mysqli("localhost", "root", "", "hotel_cleaning");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
