<?php
session_start();
include 'db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $role     = trim($_POST['role'] ?? '');

    if ($email && $password && $role) {
        // Query the database for the user
        $stmt = $conn->prepare("SELECT id, name, password, role, room FROM users WHERE email = ? AND role = ?");
        $stmt->bind_param("ss", $email, $role);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            // Support both plain-text (legacy) and hashed passwords
            $passwordMatch = ($password === $user['password'])
                || password_verify($password, $user['password']);

            if ($passwordMatch) {
                $_SESSION['user']    = $email;
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['name']    = $user['name'];
                $_SESSION['role']    = $user['role'];
                $_SESSION['room']    = $user['room'];

                if ($role === 'client') {
                    header('Location: client/dashboard.php');
                } elseif ($role === 'staff') {
                    header('Location: staff/dashboard.php');
                } elseif ($role === 'admin') {
                    header('Location: admin/dashboard.php');
                }
                exit();
            } else {
                $error = 'Invalid email or password.';
            }
        } else {
            $error = 'No account found with that email and role.';
        }
    } else {
        $error = 'Please fill in all fields.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Smart Hotel Cleaning Management</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="logo">🏨 Hotel Cleaning System</div>
        </div>
    </nav>

    <section class="auth-section">
        <div class="auth-container">
            <h2>Login to Your Account</h2>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form method="POST" class="auth-form">
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" required
                           value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>

                <div class="form-group">
                    <label for="role">Login As</label>
                    <select id="role" name="role" required>
                        <option value="">Select Role</option>
                        <option value="client"  <?php echo (($_POST['role'] ?? '') === 'client')  ? 'selected' : ''; ?>>Guest</option>
                        <option value="staff"   <?php echo (($_POST['role'] ?? '') === 'staff')   ? 'selected' : ''; ?>>Cleaning Staff</option>
                        <option value="admin"   <?php echo (($_POST['role'] ?? '') === 'admin')   ? 'selected' : ''; ?>>Administrator</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Login</button>
            </form>

            <p>Don't have an account? <a href="register.php">Create one here</a></p>
        </div>
    </section>
</body>
</html>
