<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'staff') {
    header('Location: ../login.php');
    exit();
}
include '../db.php';

$success = '';
$error   = '';
$staff_id = (int)($_SESSION['user_id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'update_status') {
        $request_id = (int)($_POST['request_id'] ?? 0);
        $new_status = in_array($_POST['new_status'], ['in_progress', 'completed'])
            ? $_POST['new_status'] : null;
        if ($request_id && $new_status) {
            $stmt = $conn->prepare(
                "UPDATE cleaning_requests SET status=?, assigned_staff=?, updated_at=NOW() WHERE id=?"
            );
            $stmt->bind_param("sii", $new_status, $staff_id, $request_id);
            $stmt->execute()
                ? $success = "Status updated to " . str_replace('_', ' ', $new_status) . "."
                : $error   = "Update failed.";
        }
    }
}

$filter = $_GET['filter'] ?? 'all';
$where  = "WHERE cr.status != 'completed'";
if ($filter === 'pending')         $where = "WHERE cr.status = 'pending'";
elseif ($filter === 'in_progress') $where = "WHERE cr.status = 'in_progress'";
elseif ($filter === 'completed')   $where = "WHERE cr.status = 'completed'";

$assignments_res = $conn->query(
    "SELECT cr.id, cr.room, cr.request_type, cr.description,
            cr.status, DATE_FORMAT(cr.created_at,'%h:%i %p') AS time,
            u.name AS guest_name
     FROM cleaning_requests cr
     LEFT JOIN users u ON cr.user_id = u.id
     $where
     ORDER BY FIELD(cr.request_type,'urgent','clean','donotclean'), cr.created_at ASC
     LIMIT 50"
);
$rooms_data = [];
if ($assignments_res) {
    while ($row = $assignments_res->fetch_assoc()) $rooms_data[] = $row;
}

$schedule_res = $conn->prepare(
    "SELECT DATE_FORMAT(schedule_date,'%Y-%m-%d') AS date,
            shift, start_time, end_time, rooms_assigned
     FROM staff_schedule WHERE staff_id=? ORDER BY schedule_date DESC LIMIT 10"
);
$schedule = [];
if ($schedule_res) {
    $schedule_res->bind_param("i", $staff_id);
    $schedule_res->execute();
    $sr = $schedule_res->get_result();
    while ($row = $sr->fetch_assoc()) $schedule[] = $row;
}

$rooms_json = json_encode($rooms_data);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff Dashboard — Hotel Cleaning</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600&family=Space+Mono:wght@700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{
  --bg:#F7F6F3;--surface:#fff;--surface2:#F1EFE8;
  --border:rgba(0,0,0,0.10);--border2:rgba(0,0,0,0.18);
  --text:#1a1a18;--muted:#6b6b67;--faint:#9e9e98;
  --accent:#1D9E75;--accent2:#0F6E56;
  --r-md:10px;--r-lg:14px;--r-xl:20px;
}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;font-size:15px;line-height:1.5;}
nav{background:var(--text);padding:0 2rem;height:56px;display:flex;align-items:center;justify-content:space-between;}
.nav-logo{font-family:'Space Mono',monospace;font-size:13px;letter-spacing:.08em;color:#fff;text-transform:uppercase;}
.nav-right{display:flex;align-items:center;gap:1.5rem;}
.nav-right a{color:rgba(255,255,255,.6);text-decoration:none;font-size:13px;transition:color .2s;}
.nav-right a:hover{color:#fff;}
.nav-badge{background:var(--accent);color:#fff;font-size:11px;font-weight:500;padding:3px 10px;border-radius:20px;}
.page{max-width:1280px;margin:0 auto;padding:2rem 1.5rem;}
.top-bar{display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;}
.top-bar h1{font-family:'Space Mono',monospace;font-size:14px;letter-spacing:.06em;text-transform:uppercase;}
.live{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--muted);}
.live-dot{width:7px;height:7px;border-radius:50%;background:var(--accent);animation:blink 2s infinite;}
@keyframes blink{0%,100%{opacity:1;}50%{opacity:.3;}}
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:1.5rem;}
.stat-card{background:var(--surface);border:.5px solid var(--border);border-radius:var(--r-lg);padding:14px 16px;}
.stat-card .num{font-family:'Space Mono',monospace;font-size:26px;font-weight:700;line-height:1;}
.stat-card .lbl{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.05em;margin-top:4px;}
.pb-wrap{height:4px;background:var(--surface2);border-radius:2px;margin-top:10px;overflow:hidden;}
.pb-fill{height:100%;border-radius:2px;transition:width .6s ease;}
.floor-card{background:var(--surface);border:.5px solid var(--border);border-radius:var(--r-xl);padding:20px 22px;margin-bottom:1.5rem;}
.floor-header{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:16px;gap:12px;}
.floor-title{font-family:'Space Mono',monospace;font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--faint);}
.legend{display:flex;gap:12px;flex-wrap:wrap;margin-top:8px;font-size:11px;color:var(--muted);}
.legend-item{display:flex;align-items:center;gap:5px;}
.legend-dot{width:11px;height:11px;border-radius:3px;flex-shrink:0;}
.floor-tabs{display:flex;gap:6px;flex-shrink:0;}
.ftab{padding:5px 14px;border-radius:20px;font-size:12px;font-family:'DM Sans',sans-serif;cursor:pointer;border:.5px solid var(--border2);background:transparent;color:var(--muted);transition:all .15s;}
.ftab.active{background:var(--text);color:#fff;border-color:var(--text);}
.ftab:hover:not(.active){background:var(--surface2);}
.map-scroll{overflow-x:auto;padding-bottom:8px;}
.map-container{display:flex;flex-direction:column;gap:4px;min-width:max-content;}
.map-row{display:flex;gap:4px;}
.corridor-line{display:flex;align-items:center;margin:5px 0;}
.corridor-line::before,.corridor-line::after{content:'';flex:1;height:1px;background:var(--border2);}
.corridor-line span{font-size:9px;letter-spacing:.2em;text-transform:uppercase;color:var(--faint);padding:0 12px;}
.room-cell{width:44px;height:40px;border-radius:7px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;border:1.5px solid transparent;transition:transform .12s;user-select:none;flex-shrink:0;}
.room-cell:hover{transform:scale(1.1);z-index:5;position:relative;}
.room-cell.selected{transform:scale(1.1);z-index:5;position:relative;outline:2.5px solid var(--text);outline-offset:2px;}
.r-icon{font-size:9px;font-weight:700;opacity:.7;line-height:1;}
.r-num{font-family:'Space Mono',monospace;font-size:10px;font-weight:700;line-height:1.3;}
.r-clean{background:#EAF3DE;border-color:#C0DD97;}.r-clean .r-icon,.r-clean .r-num{color:#3B6D11;}
.r-dirty{background:#FAEEDA;border-color:#FAC775;}.r-dirty .r-icon,.r-dirty .r-num{color:#854F0B;}
.r-urgent{background:#FCEBEB;border-color:#F7C1C1;animation:pulse-r 2s infinite;}.r-urgent .r-icon,.r-urgent .r-num{color:#A32D2D;}
.r-progress{background:#E6F1FB;border-color:#B5D4F4;}.r-progress .r-icon,.r-progress .r-num{color:#185FA5;}
.r-dnd{background:#EEEDFE;border-color:#CECBF6;}.r-dnd .r-icon,.r-dnd .r-num{color:#534AB7;}
.r-empty{background:var(--surface2);border-color:var(--border);opacity:.5;}.r-empty .r-icon,.r-empty .r-num{color:var(--faint);}
@keyframes pulse-r{0%,100%{box-shadow:0 0 0 0 rgba(226,75,74,.3);}50%{box-shadow:0 0 0 5px rgba(226,75,74,0);}}
.map-hint{font-size:10px;color:var(--faint);text-align:right;margin-top:8px;}
.detail-panel{background:var(--surface);border:.5px solid var(--border);border-radius:var(--r-xl);padding:22px 24px;margin-bottom:1.5rem;display:none;}
.detail-panel.open{display:block;}
.dp-header{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:16px;}
.dp-room-num{font-family:'Space Mono',monospace;font-size:22px;font-weight:700;}
.dp-pill{font-size:11px;font-weight:500;padding:4px 12px;border-radius:20px;}
.dp-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:14px;}
.dp-field .lbl{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.04em;margin-bottom:3px;}
.dp-field .val{font-size:14px;font-weight:500;}
.dp-note{font-size:13px;color:var(--muted);margin-bottom:16px;}
.dp-divider{height:.5px;background:var(--border);margin-bottom:16px;}
.dp-actions{display:flex;gap:8px;flex-wrap:wrap;}
.dp-btn{padding:9px 18px;border-radius:9px;font-size:13px;font-weight:500;cursor:pointer;border:.5px solid var(--border2);background:var(--surface);color:var(--text);font-family:'DM Sans',sans-serif;transition:background .15s,transform .1s;}
.dp-btn:hover{background:var(--surface2);}
.dp-btn:active{transform:scale(.97);}
.dp-btn.primary{background:var(--accent);color:#fff;border-color:var(--accent2);}
.dp-btn.primary:hover{background:var(--accent2);}
.section-title{font-family:'Space Mono',monospace;font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:var(--faint);margin-bottom:12px;}
.filters{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:1rem;}
.filter-pill{padding:6px 16px;border-radius:20px;font-size:12px;border:.5px solid var(--border2);background:var(--surface);color:var(--muted);cursor:pointer;text-decoration:none;transition:all .15s;display:inline-block;}
.filter-pill.active,.filter-pill:hover{background:var(--text);color:#fff;border-color:var(--text);}
.cards-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px;}
.req-card{background:var(--surface);border:.5px solid var(--border);border-radius:var(--r-lg);padding:16px;border-left:3px solid var(--border);}
.req-card.urgent{border-left-color:#E24B4A;}.req-card.pending{border-left-color:#EF9F27;}
.req-card.in_progress{border-left-color:#378ADD;}.req-card.completed{border-left-color:#639922;}
.req-card-top{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;}
.req-room{font-family:'Space Mono',monospace;font-size:15px;font-weight:700;}
.req-badge{font-size:10px;font-weight:600;padding:3px 8px;border-radius:20px;}
.req-detail{font-size:13px;color:var(--muted);margin:2px 0;}
.req-actions{display:flex;gap:6px;margin-top:10px;}
.req-btn{padding:6px 12px;border-radius:7px;font-size:12px;font-weight:500;cursor:pointer;border:.5px solid var(--border2);background:transparent;font-family:'DM Sans',sans-serif;transition:background .15s;color:var(--text);}
.req-btn.go{background:var(--accent);color:#fff;border-color:var(--accent2);}
.req-btn.done{background:#639922;color:#fff;border-color:#3B6D11;}
.sched-table{width:100%;border-collapse:collapse;font-size:13px;}
.sched-table th{background:var(--text);color:#fff;padding:10px 14px;text-align:left;font-weight:500;font-family:'Space Mono',monospace;font-size:10px;letter-spacing:.06em;text-transform:uppercase;}
.sched-table td{padding:10px 14px;border-bottom:.5px solid var(--border);}
.sched-table tbody tr:hover{background:var(--surface2);}
.alert{padding:12px 16px;border-radius:var(--r-md);margin-bottom:1rem;font-size:14px;}
.alert-success{background:#EAF3DE;color:#3B6D11;border:.5px solid #C0DD97;}
.alert-error{background:#FCEBEB;color:#A32D2D;border:.5px solid #F7C1C1;}
@media(max-width:768px){
  .stats-row{grid-template-columns:repeat(2,1fr);}
  .dp-grid{grid-template-columns:1fr;}
  .room-cell{width:42px;height:40px;}
  .r-num{font-size:9px;}
  .floor-header{flex-direction:column;}
}
</style>
</head>
<body>

<nav>
  <div class="nav-logo">🏨 Hotel Cleaning</div>
  <div class="nav-right">
    <span style="color:rgba(255,255,255,.5);font-size:13px;"><?php echo htmlspecialchars($_SESSION['name'] ?? $_SESSION['user']); ?></span>
    <span class="nav-badge">Staff</span>
    <a href="../logout.php">Logout</a>
  </div>
</nav>

<div class="page">

<?php if ($success): ?><div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

<div class="top-bar">
  <h1>Staff Floor Map</h1>
  <div class="live"><div class="live-dot"></div><span id="live-clock">Live</span></div>
</div>

<div class="stats-row">
  <div class="stat-card">
    <div class="num" id="s-urgent" style="color:#A32D2D;">—</div>
    <div class="lbl">Urgent</div>
    <div class="pb-wrap"><div class="pb-fill" style="background:#E24B4A;" id="pb-urgent"></div></div>
  </div>
  <div class="stat-card">
    <div class="num" id="s-dirty" style="color:#854F0B;">—</div>
    <div class="lbl">Needs Clean</div>
    <div class="pb-wrap"><div class="pb-fill" style="background:#EF9F27;" id="pb-dirty"></div></div>
  </div>
  <div class="stat-card">
    <div class="num" id="s-progress" style="color:#185FA5;">—</div>
    <div class="lbl">In Progress</div>
    <div class="pb-wrap"><div class="pb-fill" style="background:#378ADD;" id="pb-progress"></div></div>
  </div>
  <div class="stat-card">
    <div class="num" id="s-clean" style="color:#3B6D11;">—</div>
    <div class="lbl">Clean</div>
    <div class="pb-wrap"><div class="pb-fill" style="background:#639922;" id="pb-clean"></div></div>
  </div>
</div>

<div class="floor-card">
  <div class="floor-header">
    <div>
      <div class="floor-title" id="floor-title">Floor 1 — Wing A &amp; B</div>
      <div class="legend">
        <div class="legend-item"><div class="legend-dot" style="background:#EAF3DE;border:1px solid #C0DD97;"></div>Clean</div>
        <div class="legend-item"><div class="legend-dot" style="background:#FAEEDA;border:1px solid #FAC775;"></div>Needs cleaning</div>
        <div class="legend-item"><div class="legend-dot" style="background:#FCEBEB;border:1px solid #F7C1C1;"></div>Urgent</div>
        <div class="legend-item"><div class="legend-dot" style="background:#E6F1FB;border:1px solid #B5D4F4;"></div>In progress</div>
        <div class="legend-item"><div class="legend-dot" style="background:#EEEDFE;border:1px solid #CECBF6;"></div>DND</div>
      </div>
    </div>
    <div class="floor-tabs">
      <button class="ftab active" onclick="setFloor(1,this)">Floor 1</button>
      <button class="ftab" onclick="setFloor(2,this)">Floor 2</button>
      <button class="ftab" onclick="setFloor(3,this)">Floor 3</button>
      <button class="ftab" onclick="setFloor(4,this)">Floor 4</button>
      <button class="ftab" onclick="setFloor(5,this)">Floor 5</button>
    </div>
  </div>
  <div class="map-scroll">
    <div class="map-container" id="map-container"></div>
  </div>
  <div class="map-hint">Scroll horizontally if needed · Tap a room to view details &amp; take action</div>
</div>

<div class="detail-panel" id="detail-panel">
  <div class="dp-header">
    <div>
      <div style="font-size:10px;color:var(--faint);text-transform:uppercase;letter-spacing:.1em;margin-bottom:4px;">Selected Room</div>
      <div class="dp-room-num" id="dp-room">—</div>
    </div>
    <div class="dp-pill" id="dp-pill"></div>
  </div>
  <div class="dp-grid">
    <div class="dp-field"><div class="lbl">Guest</div><div class="val" id="dp-guest">—</div></div>
    <div class="dp-field"><div class="lbl">Request type</div><div class="val" id="dp-type">—</div></div>
    <div class="dp-field"><div class="lbl">Requested at</div><div class="val" id="dp-time">—</div></div>
    <div class="dp-field"><div class="lbl">Assigned staff</div><div class="val" id="dp-staff">—</div></div>
  </div>
  <div class="dp-note" id="dp-note"></div>
  <div class="dp-divider"></div>
  <div class="dp-actions" id="dp-actions"></div>
</div>

<div style="margin-bottom:1rem;">
  <div class="section-title">All Assignments</div>
  <div class="filters">
    <a href="?filter=all"         class="filter-pill <?php echo $filter==='all'?'active':''; ?>">All</a>
    <a href="?filter=pending"     class="filter-pill <?php echo $filter==='pending'?'active':''; ?>">Pending</a>
    <a href="?filter=in_progress" class="filter-pill <?php echo $filter==='in_progress'?'active':''; ?>">In Progress</a>
    <a href="?filter=completed"   class="filter-pill <?php echo $filter==='completed'?'active':''; ?>">Completed</a>
  </div>
  <div class="cards-grid">
  <?php foreach ($rooms_data as $req):
    $bc = $req['status']==='completed'?'completed':($req['request_type']==='urgent'?'urgent':$req['status']);
    $bs=''; $bl=ucfirst($req['request_type']);
    if($req['request_type']==='urgent')         {$bs='background:#FCEBEB;color:#A32D2D;';}
    elseif($req['request_type']==='donotclean') {$bs='background:#EEEDFE;color:#534AB7;';$bl='DND';}
    elseif($req['status']==='in_progress')      {$bs='background:#E6F1FB;color:#185FA5;';}
    elseif($req['status']==='completed')        {$bs='background:#EAF3DE;color:#3B6D11;';}
    else                                         {$bs='background:#FAEEDA;color:#854F0B;';}
  ?>
  <div class="req-card <?php echo $bc; ?>">
    <div class="req-card-top">
      <div class="req-room">Room <?php echo htmlspecialchars($req['room']); ?></div>
      <span class="req-badge" style="<?php echo $bs; ?>"><?php echo $bl; ?></span>
    </div>
    <div class="req-detail"><strong>Guest:</strong> <?php echo htmlspecialchars($req['guest_name']??'Unknown'); ?></div>
    <div class="req-detail"><strong>Status:</strong> <?php echo ucfirst(str_replace('_',' ',$req['status'])); ?></div>
    <div class="req-detail"><strong>Time:</strong> <?php echo $req['time']; ?></div>
    <?php if($req['description']): ?><div class="req-detail" style="font-size:12px;color:var(--faint);margin-top:4px;"><?php echo htmlspecialchars($req['description']); ?></div><?php endif; ?>
    <?php if($req['status']!=='completed'&&$req['request_type']!=='donotclean'): ?>
    <div class="req-actions">
      <?php if($req['status']==='pending'): ?>
      <form method="POST" style="display:inline;">
        <input type="hidden" name="action" value="update_status">
        <input type="hidden" name="request_id" value="<?php echo $req['id']; ?>">
        <input type="hidden" name="new_status" value="in_progress">
        <button type="submit" class="req-btn go">▶ Start</button>
      </form>
      <?php endif; ?>
      <form method="POST" style="display:inline;">
        <input type="hidden" name="action" value="update_status">
        <input type="hidden" name="request_id" value="<?php echo $req['id']; ?>">
        <input type="hidden" name="new_status" value="completed">
        <button type="submit" class="req-btn done">✓ Complete</button>
      </form>
    </div>
    <?php elseif($req['status']==='completed'): ?>
      <div style="font-size:12px;color:#3B6D11;font-weight:600;margin-top:8px;">✓ Done</div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
  <?php if(empty($rooms_data)): ?><div style="color:var(--faint);font-size:14px;padding:20px 0;">No assignments found.</div><?php endif; ?>
  </div>
</div>

<div style="margin-top:2rem;margin-bottom:3rem;">
  <div class="section-title">Your Schedule</div>
  <?php if($schedule): ?>
  <div style="background:var(--surface);border:.5px solid var(--border);border-radius:var(--r-lg);overflow:hidden;">
  <table class="sched-table">
    <thead><tr><th>Date</th><th>Shift</th><th>Start</th><th>End</th><th>Rooms</th></tr></thead>
    <tbody>
    <?php foreach($schedule as $s): ?>
    <tr>
      <td><?php echo $s['date']; ?></td>
      <td><?php echo htmlspecialchars($s['shift']); ?></td>
      <td><?php echo htmlspecialchars($s['start_time']); ?></td>
      <td><?php echo htmlspecialchars($s['end_time']); ?></td>
      <td><?php echo htmlspecialchars($s['rooms_assigned']); ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php else: ?><p style="color:var(--faint);font-size:14px;">No schedule entries. Contact your admin.</p><?php endif; ?>
</div>

</div>

<script>
const DB_ROOMS = <?php echo $rooms_json; ?>;
function makeFloor(f){
  const prefix=f*100;
  const rowA=[],rowB=[],rowC=[];
  for(let i=1;i<=10;i++)rowA.push(String(prefix+i));
  for(let i=11;i<=20;i++)rowB.push(String(prefix+i));
  for(let i=21;i<=30;i++)rowC.push(String(prefix+i));
  const labels={1:"Floor 1 — Wing A · Wing B · Wing C",2:"Floor 2 — Wing A · Wing B · Wing C",3:"Floor 3 — Wing A · Wing B · Wing C",4:"Floor 4 — Wing A · Wing B · Wing C",5:"Floor 5 — Suites & Premium"};
  return{title:labels[f],rows:[rowA,rowB,rowC]};
}
const FLOORS={1:makeFloor(1),2:makeFloor(2),3:makeFloor(3),4:makeFloor(4),5:makeFloor(5)};
const roomLookup={};
DB_ROOMS.forEach(r=>{roomLookup[r.room]=r;});
const DUMMY=["clean","clean","clean","dirty","urgent","in_progress","donotclean","vacant"];
function dummyRoom(n){const t=DUMMY[parseInt(n)%DUMMY.length];return{room:n,request_type:t,status:t==="in_progress"?"in_progress":t==="clean"?"completed":"pending",guest_name:t==="vacant"?null:"Guest "+n,description:"",time:""};}
function getRoom(n){return roomLookup[n]||dummyRoom(n);}
function cellCls(r){if(r.request_type==="urgent")return"r-urgent";if(r.request_type==="donotclean")return"r-dnd";if(r.status==="in_progress")return"r-progress";if(r.status==="completed"||r.request_type==="clean")return"r-clean";if(!r.guest_name)return"r-empty";return"r-dirty";}
function cellIco(r){if(r.request_type==="urgent")return"!";if(r.request_type==="donotclean")return"⊘";if(r.status==="in_progress")return"↻";if(r.status==="completed"||r.request_type==="clean")return"✓";if(!r.guest_name)return"○";return"~";}
function statusLbl(r){if(r.request_type==="urgent")return"Urgent";if(r.request_type==="donotclean")return"Do Not Disturb";if(r.status==="in_progress")return"In Progress";if(r.status==="completed")return"Complete";if(!r.guest_name)return"Vacant";return"Needs Cleaning";}
function pillStyle(r){if(r.request_type==="urgent")return"background:#FCEBEB;color:#A32D2D;";if(r.request_type==="donotclean")return"background:#EEEDFE;color:#534AB7;";if(r.status==="in_progress")return"background:#E6F1FB;color:#185FA5;";if(r.status==="completed")return"background:#EAF3DE;color:#3B6D11;";if(!r.guest_name)return"background:#F1EFE8;color:#6b6b67;";return"background:#FAEEDA;color:#854F0B;";}
let curFloor=1,selRoom=null;
function buildMap(floor){
  const f=FLOORS[floor];
  document.getElementById("floor-title").textContent=f.title;
  const cont=document.getElementById("map-container");
  cont.innerHTML="";
  let urg=0,dirt=0,prog=0,cln=0,tot=0;
  f.rows.forEach((row,ri)=>{
    if(ri>0){const c=document.createElement("div");c.className="corridor-line";c.innerHTML="<span>Corridor "+(ri)+"</span>";cont.appendChild(c);}
    const rowDiv=document.createElement("div");rowDiv.className="map-row";
    row.forEach(num=>{
      tot++;const r=getRoom(num);
      if(r.request_type==="urgent")urg++;
      else if(r.status==="in_progress")prog++;
      else if(r.status==="completed"||r.request_type==="clean")cln++;
      else if(r.guest_name)dirt++;
      const cell=document.createElement("div");
      cell.className="room-cell "+cellCls(r);cell.id="cell-"+num;
      cell.innerHTML=`<div class="r-icon">${cellIco(r)}</div><div class="r-num">${num}</div>`;
      cell.addEventListener("click",()=>selectRoom(num));
      rowDiv.appendChild(cell);
    });
    cont.appendChild(rowDiv);
  });
  document.getElementById("s-urgent").textContent=urg;
  document.getElementById("s-dirty").textContent=dirt;
  document.getElementById("s-progress").textContent=prog;
  document.getElementById("s-clean").textContent=cln;
  document.getElementById("pb-urgent").style.width=(urg/tot*100)+"%";
  document.getElementById("pb-dirty").style.width=(dirt/tot*100)+"%";
  document.getElementById("pb-progress").style.width=(prog/tot*100)+"%";
  document.getElementById("pb-clean").style.width=(cln/tot*100)+"%";
}
function selectRoom(num){
  if(selRoom){const p=document.getElementById("cell-"+selRoom);if(p)p.classList.remove("selected");}
  selRoom=num;
  const el=document.getElementById("cell-"+num);if(el)el.classList.add("selected");
  const r=getRoom(num);
  document.getElementById("dp-room").textContent="Room "+num;
  document.getElementById("dp-pill").textContent=statusLbl(r);
  document.getElementById("dp-pill").style.cssText=pillStyle(r)+"padding:4px 12px;border-radius:20px;font-size:11px;font-weight:500;";
  document.getElementById("dp-guest").textContent=r.guest_name||"—";
  document.getElementById("dp-type").textContent=r.request_type==="donotclean"?"Do Not Clean":(r.request_type||"—").replace("_"," ");
  document.getElementById("dp-time").textContent=r.time||"—";
  document.getElementById("dp-staff").textContent=r.assigned_staff_name||"Unassigned";
  const NOTES={urgent:"Guest reported an issue — needs immediate attention.",donotclean:"Guest requested privacy. Do not enter.",in_progress:"Cleaning currently underway.",clean:"Room inspected and ready.",vacant:"Unoccupied — scheduled for turnover."};
  document.getElementById("dp-note").textContent=NOTES[r.request_type]||NOTES[r.status]||r.description||"No notes.";
  const acts=document.getElementById("dp-actions");acts.innerHTML="";
  if(r.id&&r.status!=="completed"&&r.request_type!=="donotclean"){
    if(r.status==="pending"){
      const f=document.createElement("form");f.method="POST";f.style.display="inline";
      f.innerHTML=`<input type="hidden" name="action" value="update_status"><input type="hidden" name="request_id" value="${r.id}"><input type="hidden" name="new_status" value="in_progress"><button type="submit" class="dp-btn primary">▶ Start Cleaning</button>`;
      acts.appendChild(f);
    }
    if(r.status==="in_progress"){
      const f=document.createElement("form");f.method="POST";f.style.display="inline";
      f.innerHTML=`<input type="hidden" name="action" value="update_status"><input type="hidden" name="request_id" value="${r.id}"><input type="hidden" name="new_status" value="completed"><button type="submit" class="dp-btn primary">✓ Mark Complete</button>`;
      acts.appendChild(f);
    }
  }
  document.getElementById("detail-panel").classList.add("open");
  document.getElementById("detail-panel").scrollIntoView({behavior:"smooth",block:"nearest"});
}
function setFloor(n,el){
  document.querySelectorAll(".ftab").forEach(t=>t.classList.remove("active"));
  el.classList.add("active");curFloor=n;selRoom=null;
  document.getElementById("detail-panel").classList.remove("open");
  buildMap(n);
}
function tick(){const now=new Date();document.getElementById("live-clock").textContent=now.toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"})+" · "+now.toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"});}
buildMap(1);tick();setInterval(tick,30000);
</script>
</body>
</html>
